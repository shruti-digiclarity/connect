# Import the necessary modules for this flow to work
import json
import os
import logging
import boto3

# Establish logging configuration
logger = logging.getLogger()

def vm_to_connect_task(writer_payload, contact_id, vm_task_queue_id):

    # Debug lines for troubleshooting
    print(f"writer_payload : {writer_payload} , contact_id : {contact_id}")

    # Establish needed clients and resources
    try:
        connect_client = boto3.client('connect')
        print('********** Clients initialized **********')
    
    except Exception as e:
        logger.error('********** VMX Initialization Error: Could not establish needed clients **********')
        logger.error(e)

        return {'status':'complete','result':'ERROR','reason':'Failed to Initialize clients'}

    print('Beginning Voicemail to Task')

    # contact_flow = os.environ['default_task_flow']
    callback_number = writer_payload["json_attributes"].get("callback_number")
    # task_queue_id = writer_payload["json_attributes"].get("ch-vm-task-queue-id")
    cleaned_callback_number = callback_number.strip()
    phone_number = f"+{cleaned_callback_number}"

    try:
        create_task = connect_client.start_task_contact(
            InstanceId=writer_payload['instance_id'],
            ContactFlowId=os.environ.get('TASK_FLOW_ID'),
            PreviousContactId=writer_payload['contact_id'],
            Attributes={
                'Callback_Number': phone_number,
                'VM_Task_Queue': vm_task_queue_id
            },
            # Name='Voicemail for ' + writer_payload['json_attributes']['entity_name'],
            Name='Voicemail from ' + phone_number,
            References={
                'Voicemail Timestamp': {
                    'Value': writer_payload['json_attributes']['vm_dateTime'],
                    'Type': 'STRING'
                },
                'Click the link below to play voicemail recording': {
                    'Value': writer_payload['json_attributes']['presigned_url'],
                    'Type': 'URL'
                }
            },
            Description=writer_payload['json_attributes']['transcript_contents'],
            ClientToken=writer_payload['contact_id']
        )
        print('********** Task Created **********')
        print(create_task)

        return 'success'

    except Exception as e:
        logger.error('********** Failed to create task **********')
        logger.error(e)

        return 'fail'