import boto3
import logging
from botocore.client import Config
import os

logger = logging.getLogger()


def lambda_handler(event, context):

    print(f"event : {event}")
    contact_id = event["contact_id"]
    print(f"contact_id : {contact_id}")

    response = {}

    response.update({"result": "success"})

    try:
        use_region = os.environ["AWS_REGION"]

        # Set the sig version and config options
        my_config = Config(
            region_name=use_region,
            signature_version="s3v4",
            retries={"max_attempts": 10, "mode": "standard"},
        )
        s3_client = boto3.client("s3", config=my_config)

    except Exception as e:
        logger.error(f"S3 client failed to initialize , contact_id : {contact_id}")
        logger.error(e)
        response.update(
            {"status": "complete", "result": "ERROR", "reason": "s3 client init failed"}
        )

        return response

    # Generate the presigned URL and return
    try:

        vm_mode = event["vm_mode"]
        expires_in = 7 * 86400

        presigned_url = s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": event["recording_bucket"], "Key": event["recording_key"]},
            ExpiresIn=expires_in,
        )

        print(f"Presigned URL: {presigned_url}")
        response.update({"presigned_url": presigned_url})

        return response

    except Exception as e:
        logger.error(f"Presigned URL Failed to generate , contact_id : {contact_id}")
        logger.error(e)
        response.update(
            {
                "status": "complete",
                "result": "ERROR",
                "reason": "presigned url generation failed",
            }
        )

        return response
