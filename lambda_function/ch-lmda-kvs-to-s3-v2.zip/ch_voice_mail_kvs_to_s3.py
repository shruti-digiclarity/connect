from defusedxml.xmlrpc import monkey_patch
monkey_patch()

import defusedxml
defusedxml.defuse_stdlib()

import datetime
import boto3
from botocore.config import Config
import os
import json
import base64
import logging
import time
import re
from amazon_kinesis_video_consumer_library.kinesis_video_streams_parser import KvsConsumerLibrary
from amazon_kinesis_video_consumer_library.kinesis_video_fragment_processor import KvsFragementProcessor

logger = logging.getLogger()

def lambda_handler(event, context):

    print(f"event : {event}")

    # Process the records coming in
    try:
        for record in event['Records']:
            processor = ConnectAudioProcessor()
            processor.process_record(record)
    
    except Exception as e:
        logger.error(e)
        print('Could not process records')
        return {'status':'complete','result':'ERROR','reason':'Failed to process records'}


class ConnectAudioProcessor:
    def __init__(self):
        # Define the initialization parameters
        try:
            self.kvs_fragment_processor = KvsFragementProcessor()
            self.last_good_fragment_tags = None
            self.is_done = False
            self.contact_id = None
            self.audio_bytes = bytearray()
            self.encoded_tags = None

        except Exception as e:
            logger.error(e)
            print('Could not initialize parameters')
            return {'status':'complete','result':'ERROR','reason':'Could not initialize parameters'}

    def process_record(self, record):
        # Load the record data and decode
        try:
            record_data = json.loads(base64.b64decode(record['kinesis']['data']))
            print('Record data loaded: ',record_data)

        except Exception as e:
            logger.error(e)
            print('Could not load record data')
            return {'status':'complete','result':'ERROR','reason':'Could not load record data'}
    
        if record_data['Recordings'] is None:
            print('No recordings data found')
            return {'status':'complete','result':'ERROR','reason':'No record data'}
        
        else:
            # Load the data needed to process KVS and setup tags
            try:

                self.contact_id = record_data['ContactId']
                recording = record_data['Recordings'][0]
                stream_arn = recording['Location']
                start_timestamp = recording['StartTimestamp']
                end_timestamp = recording['StopTimestamp']
                start_fragment = recording['FragmentStartNumber']
                stop_fragment = recording['FragmentStopNumber']
                attr_tag_container = ''
                attribute_details = record_data['Attributes']
                languageCode = attribute_details['languageCode']
                countryCode = attribute_details['countryCode']
                vm_lang_value = f'{languageCode}-{countryCode}'
                vm_kvs_status = attribute_details['vm_kvs_status']
                instance_arn = record_data['InstanceARN']
                instance_id = instance_arn.split("/")[-1]
                vm_from = record_data['CustomerEndpoint']['Address']

                if vm_kvs_status == "0":
                    return {"status": "complete", "result": "ERROR", "reason": "vm_kvs_status is set to 0"}
                
                attr_tag_container = f'vm_lang={vm_lang_value}&instance_id={instance_id}&vm_from={vm_from}'
                print(f"contactId : {self.contact_id} , attr_tag_container : {attr_tag_container}")

                self.encoded_tags = re.sub(r'&\s*$', '', attr_tag_container)
            except Exception as e:
                logger.error(e)
                print(f"Could not load necessary data of contact_id : {self.contact_id}")
                return {'status':'complete','result':'ERROR','reason':'Could not load necessary data'}

            # Retrieve and generate the fragment list
            try:
                fragments = self.list_fragments(
                    stream_arn,
                    datetime.datetime.fromisoformat(start_timestamp),
                    datetime.datetime.fromisoformat(end_timestamp)
                )
    
                fragment_numbers = list(map(lambda fragment: fragment['FragmentNumber'], fragments))

                # Make sure the start and stop fragments are in the list
                if start_fragment not in fragment_numbers:
                    fragment_numbers.append(start_fragment)

                if stop_fragment not in fragment_numbers:
                    fragment_numbers.append(stop_fragment)

                # Sort fragment list
                fragment_numbers.sort(key=int)
                
            except Exception as e:
                logger.error(e)
                print(f"Could not generate fragment list of contactId : {self.contact_id}")
                return {'status':'complete','result':'ERROR','reason':'Could not generate fragment list'}

            # Process fragment list
            try:
                media_response = self.get_media_for_fragment_list(
                    stream_arn,
                    fragment_numbers
                )
            
            except Exception as e:
                logger.error(e)
                print(f"Could not process fragment list of contactId : {self.contact_id}")
                return {'status':'complete','result':'ERROR','reason':'Could not process fragment list'}

            # Configure and initialize the stream consumer
            try:
                stream_consumer = KvsConsumerLibrary(
                    stream_arn,
                    media_response,
                    self.on_fragment_arrived,
                    self.on_stream_read_complete,
                    self.on_stream_read_exception
                )
    
                stream_consumer.start()
                print(f"Consumer started , contactId : {self.contact_id}")
        
                while not self.is_done:
                    time.sleep(5)
                else:
                    stream_consumer.stop_thread()

            except Exception as e:
                logger.error(e)
                print(f"Could not consume stream , contactId : {self.contact_id}")
                return {'status':'complete','result':'ERROR','reason':'Could not consume stream'}
    
    # Function to retrieve the data endpoint for KVS processing
    def get_kinesis_video_data_endpoint(self, stream_arn, api_name):

        try:
            client = boto3.client('kinesisvideo', region_name='us-east-1')
            response = client.get_data_endpoint(
                StreamARN=stream_arn,
                APIName=api_name
            )
            print(f"contactId : {self.contact_id} , Data Endpoint: {response['DataEndpoint']}")
        
            return response['DataEndpoint']
        
        except Exception as e:
            logger.error(e)
            print(f"Could not get stream endpoint , contactId : {self.contact_id}")
            return {'status':'complete','result':'ERROR','reason':'Could not get stream endpoint'}
    
    #  Function to get the fragment list
    def list_fragments(self, stream_arn, start_timestamp, end_timestamp):

        try:
            endpoint = self.get_kinesis_video_data_endpoint(stream_arn, 'LIST_FRAGMENTS')
            client = boto3.client('kinesis-video-archived-media', endpoint_url=endpoint)
            response = client.list_fragments(
                StreamARN=stream_arn,
                MaxResults=1000,
                FragmentSelector={
                    'FragmentSelectorType': 'SERVER_TIMESTAMP',
                    'TimestampRange': {
                        'StartTimestamp': start_timestamp,
                        'EndTimestamp': end_timestamp
                    }
                }
            )

            return response['Fragments']
        
        except Exception as e:
            logger.error(e)
            print(f"Could not get fragment list of contactId : {self.contact_id}")
            return {'status':'complete','result':'ERROR','reason':'Could not get fragment list'}
    
    # Function to get the media
    def get_media_for_fragment_list(self, stream_arn, fragment_numbers):
        try:
            endpoint = self.get_kinesis_video_data_endpoint(stream_arn, 'GET_MEDIA_FOR_FRAGMENT_LIST')
            client = boto3.client('kinesis-video-archived-media', endpoint_url=endpoint)
            response = client.get_media_for_fragment_list(
                StreamARN=stream_arn,
                Fragments=fragment_numbers
            )        
            return response
        
        except Exception as e:
            logger.error(e)
            print(f"Could not process media, contactId : {self.contact_id}")
            return {'status':'complete','result':'ERROR','reason':'Could not process media'}

    # Function to write the bytes to a mav file    
    def write_wav_to_s3(self):

        try:
            wav_bytes = self.kvs_fragment_processor.convert_track_to_wav(self.audio_bytes)
            client = boto3.client('s3')
            client.put_object(Body=wav_bytes.getvalue(), Bucket=f'{os.getenv("s3_recordings_bucket")}', Key=f'{self.contact_id}.wav', Tagging=self.encoded_tags, ContentType='audio/x-wav')
            
        except Exception as e:
            logger.error(e)
            print(f"Could not write data to S3 , contactId : {self.contact_id}")

    # KVS Consumer Library call-backs
    def on_fragment_arrived(self, stream_name, fragment_bytes, fragment_dom, fragment_receive_duration):

        try:
            # use stream_name to identify fragments where multiple instances of the KvsConsumerLibrary are running on different streams.
            # Get the fragment tags and save in local parameter.
            self.last_good_fragment_tags = self.kvs_fragment_processor.get_fragment_tags(fragment_dom)
            
            if (self.last_good_fragment_tags['ContactId'] != self.contact_id):
                print(f'######## Fragment ContactId tag [{self.last_good_fragment_tags['ContactId']} does not equals current contact id {self.contact_id}.  Skipping this fragment')
            else:
                bytes = self.kvs_fragment_processor.get_connect_fragment_audio_track_from_customer_as_bytes(fragment_dom)
                self.audio_bytes.extend(bytes)

        except Exception as err:
            logger.error(f'on_fragment_arrived Error: {err}')

    def on_stream_read_complete(self, stream_name):

        # Do something here to tell the application that reading from the stream ended gracefully
        self.is_done = True        
        self.write_wav_to_s3()
        

    def on_stream_read_exception(self, stream_name, error):

        # Here we just log the error
        logger.error(f'contactId : {self.contact_id} , ####### ERROR: Exception on read stream: {stream_name}\n####### Fragment Tags:\n{self.last_good_fragment_tags}\nError Message:{error}')
