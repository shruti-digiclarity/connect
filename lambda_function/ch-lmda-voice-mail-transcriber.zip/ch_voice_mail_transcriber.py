import boto3
from botocore.config import Config
import os
import logging
import time

logger = logging.getLogger()

s3_client = boto3.client("s3")
def lambda_handler(event, context):
    print(f"event : {event}")
    
    # Establish needed clients and resources
    try:
        
        print("s3 client defined")
    except Exception as e:
        logger.error("VM Initialization Error: Could not establish needed clients")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to Initialize clients",
        }

    # Grab incoming data elements from the S3 event
    try:
        print("fetching event details...")
        recording_key = event["Records"][0]["s3"]["object"]["key"]
        recording_name = recording_key.replace("voicemail_recordings/", "")
        contact_id = recording_name.replace(".wav", "")
        recording_bucket = event["Records"][0]["s3"]["bucket"]["name"]
        recording_region = event["Records"][0]["awsRegion"]
        print(f"contact_id : {contact_id}")

    except Exception as e:
        logger.error("Failed to extract data from event")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to extract data from event",
        }

    # Establish the S3 client and get the object tags
    try:
        print("fetching tags...",recording_bucket,recording_key)
        print(s3_client.get_object_tagging(
            Bucket=recording_bucket, Key=recording_key
        ))
        object_data = s3_client.get_object_tagging(
            Bucket=recording_bucket, Key=recording_key
        )
        print("object_data : ", object_data )
        object_tags = object_data["TagSet"]
        print("Object tags: ",object_tags)
        loaded_tags = {}

        for i in object_tags:
            loaded_tags.update({i["Key"]: i["Value"]})

    except Exception as e:
        logger.error(f"Failed to load tags from object, contactId : {contact_id}")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to load tags from object",
        }

    # Build the Recording URL
    try:
        print("building recording url...")
        recording_url = "https://{0}.s3-{1}.amazonaws.com/{2}".format(
            recording_bucket, recording_region, recording_key
        )
        print(f"recording_url : {recording_url}")
    except Exception as e:
        logger.error(f"Failed to generate recording URL, contactId : {contact_id}")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to generate recording URL",
        }

    # Do the transcription
    try:
        # Establish the client
        transcribe_client = boto3.client("transcribe")

        # Submit the transcription job
        transcribe_response = transcribe_client.start_transcription_job(
            TranscriptionJobName="vm_" + contact_id + "_" + str(round(time.time())),
            LanguageCode=loaded_tags["vm_lang"],
            MediaFormat="wav",
            Media={"MediaFileUri": recording_url},
            OutputBucketName=os.getenv("s3_transcripts_bucket"),
        )
        print("Transcription job successed")
        return {"status": "complete", "result": "voicemail processed"}

    except Exception as e:
        logger.error(f"Transcription job rejected , contactId : {contact_id}")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Transcription job rejected",
        }
