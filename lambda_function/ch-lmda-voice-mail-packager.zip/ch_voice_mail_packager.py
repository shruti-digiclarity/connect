import json
import os
import logging
import boto3
from botocore.config import Config
from datetime import datetime

import ch_voice_mail_smtp_email

logger = logging.getLogger()


def lambda_handler(event, context):

    print(f"event : {event}")

    # Establish required clients and resources
    try:
        session = boto3.Session(region_name="us-east-1")
        connect_client = boto3.client("connect")
        lambda_client = boto3.client("lambda")
        s3_client = boto3.client("s3")
        s3_resource = session.resource("s3")

    except Exception as e:
        logger.error("VM INITIALIZATION: Failed to initialize clients")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to initialize",
        }

    # Establish writer data
    writer_payload = {}

    # Establish data for transcript and recording, and clear out write tests.
    try:
        original_transcript_key = event["Records"][0]["s3"]["object"]["key"]
        print("original_transcript_key:", original_transcript_key)
        if original_transcript_key == ".write_access_check_file.temp":
            return "********** WRITE TEST - IGNORE **********"
        transcript_key = original_transcript_key[3:]
        transcript_job = transcript_key.replace(".json", "")
        contact_id = transcript_job.split("_", 1)[0]
        recording_key = contact_id + ".wav"
        transcript_bucket = os.environ["s3_transcripts_bucket"]
        recording_bucket = os.environ["s3_recordings_bucket"]
        print(f"contact_id : {contact_id}")

    except Exception as e:
        logger.error("Record Result: Failed to extract keys")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to extract keys",
        }

    # Extract the tags from the recording object
    try:
        object_data = s3_client.get_object_tagging(
            Bucket=recording_bucket, Key=recording_key
        )

        object_tags = object_data["TagSet"]
        loaded_tags = {}

        for i in object_tags:
            loaded_tags.update({i["Key"]: i["Value"]})

    except Exception as e:
        logger.error(
            f"Record Result: Failed to extract tags , contact_id : {contact_id}"
        )
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to extract tags",
        }

    # Grab the transcript from S3
    try:
        transcript_object = s3_resource.Object(
            transcript_bucket, original_transcript_key
        )
        file_content = transcript_object.get()["Body"].read().decode("utf-8")
        json_content = json.loads(file_content)
        transcript_contents = json_content["results"]["transcripts"][0]["transcript"]

    except Exception as e:
        logger.error(f"Failed to retrieve transcript , contact_id : {contact_id}")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to retrieve transcript",
        }

    # Set instance attributes
    try:
        instance_id = loaded_tags["instance_id"]
        vm_from = loaded_tags["vm_from"]
        writer_payload.update({"instance_id": instance_id, "contact_id": contact_id})

    except Exception as e:
        logger.error(
            f"Record Result: Failed to set instance attributess , contact_id : {contact_id}"
        )
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to set instance attributes",
        }

    # Get the current date and time in UTC using timezone-aware objects
    try:
        current_datetime = datetime.now()
        formatted_datetime = current_datetime.strftime(
            "%A, %b %d at %I:%M %p (Instance Time)"
        )

    except Exception as e:
        logger.error(
            f"Record Result: Failed to get timestamp , contact_id : {contact_id}"
        )
        logger.error(e)

        formatted_datetime = "UNKNOWN"

    # Get the existing contact attributes from the call and append the standard vars for voicemail to the attributes
    try:
        contact_attributes = connect_client.get_contact_attributes(
            InstanceId=instance_id, InitialContactId=contact_id
        )
        json_attributes = contact_attributes["Attributes"]
        json_attributes.update(
            {
                "transcript_contents": transcript_contents,
                "callback_number": vm_from,
                "vm_dateTime": formatted_datetime,
            }
        )
        writer_payload.update({"json_attributes": json_attributes})
        contact_attributes = json.dumps(contact_attributes["Attributes"])

    except Exception as e:
        logger.error(
            f"Record Result: Failed to extract attributes , contact_id : {contact_id}"
        )
        logger.error(e)

        contact_attributes = "UNKNOWN"

    vm_mode = "email"

    # Invoke presigner Lambda to generate presigned URL for recording
    if vm_mode == "email":

        try:
            input_params = {
                "recording_bucket": recording_bucket,
                "recording_key": recording_key,
                "vm_mode": vm_mode,
                "contact_id": contact_id,
            }

            lambda_response = lambda_client.invoke(
                FunctionName=os.environ["presigner_function_arn"],
                InvocationType="RequestResponse",
                Payload=json.dumps(input_params),
            )
            response_from_presigner = json.load(lambda_response["Payload"])
            raw_url = response_from_presigner["presigned_url"]
            json_attributes.update({"presigned_url": raw_url})
            writer_payload.update({"presigned_url": raw_url})

        except Exception as e:
            logger.error(
                f"Record Result: Failed to generate presigned URL , contact_id : {contact_id}"
            )
            logger.error(e)

            return {
                "status": "complete",
                "result": "ERROR",
                "reason": "Failed to generate presigned URL",
            }

    if vm_mode == "email":

        try:

            write_vm = ch_voice_mail_smtp_email.vm_to_smtp_email(
                writer_payload, contact_id, original_transcript_key, recording_key
            )
            print(f"write_vm : {write_vm}");
        except Exception as e:
            logger.error(
                f"Failed to activate email function , contact_id : {contact_id}"
            )
            logger.error(e)

            return {
                "status": "complete",
                "result": "ERROR",
                "reason": "Failed to activate email function",
            }

    else:
        logger.error(f"Invalid mode selection , contact_id : {contact_id}")
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Invalid mode selection",
        }

    if write_vm == "success":
        print(f"VM successfully written , contact_id : {contact_id}")

    else:
        logger.error(f"VM failed to write, contact_id : {contact_id}")
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Record VM failed to write",
        }

    # Clear the vm_kvs_status for this contact
    try:
        update_flag = connect_client.update_contact_attributes(
            InitialContactId=contact_id,
            InstanceId=instance_id,
            Attributes={"vm_kvs_status": "0"},
        )

    except Exception as e:
        logger.error(f"Failed to change vm_kvs_status , contact_id : {contact_id}")
        logger.error(e)

    return {"status": "complete", "result": "Record processed"}
