import logging
import os
import smtplib
import boto3
from botocore.config import Config
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import urllib.request

logger = logging.getLogger()

# Get table name from environment variable
TABLE_NAME = os.environ.get('CONFIG_TABLE_NAME')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(TABLE_NAME)
    
# Fetch HTML content from DynamoDB
def load_html_from_dynamodb(path_value):
    """Fetches HTML content from DynamoDB using a key"""
    try:
        response = table.get_item(Key={'path': path_value})
        if 'Item' in response:
            return response['Item']['body']
        else:
            raise Exception("Item not found in DynamoDB")
    except Exception as e:
        print(f"Error fetching HTML content from DynamoDB: {e}")
        return None
    
# Function to replace dynamic placeholders with actual values
def replace_dynamic_values(html_content, voicemail_from, transcript, presigned_url):
    """Replaces dynamic placeholders in the HTML with actual values"""
    html_content = html_content.replace("{{voicemail_from}}", voicemail_from)
    html_content = html_content.replace("{{transcript}}", transcript)
    html_content = html_content.replace("{{presigned_url}}", presigned_url)
    return html_content

def vm_to_smtp_email(
    writer_payload, contact_id, original_transcript_key, recording_key
):
    print(f"writer_payload : {writer_payload} , contact_id : {contact_id}")

    # Establish clients (In this case, SMTP)
    try:
        print(f"SMTP Client initialized , contact_id : {contact_id}")
    except Exception as e:
        logger.error(
            f"VM Initialization Error: Could not initialize SMTP , contact_id : {contact_id}"
        )
        logger.error(e)
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to Initialize clients",
        }

    callback_number = writer_payload["json_attributes"].get("callback_number")
    cleaned_callback_number = callback_number.strip()
    phone_number = f"+{cleaned_callback_number}"

    vm_email_target_address = writer_payload["json_attributes"].get("ch-vm-email-address")

    if "@" not in vm_email_target_address:
        return "fail"

    voicemail_from = writer_payload["json_attributes"].get(
        "callback_number", "Unknown Caller"
    )
    transcript = writer_payload["json_attributes"].get(
        "transcript_contents", "No transcription available."
    )
    presigned_url = writer_payload["json_attributes"].get("presigned_url", "#")
    lob_name = writer_payload["json_attributes"].get("lobName")
    path_value = f"/vm-email-template/{lob_name}"

    html_part = load_html_from_dynamodb(path_value)
    if not html_part:
        print("No HTML content found for email.")
        return "failure"
    
    # Replace dynamic values in the HTML content
    html_part = replace_dynamic_values(html_part, voicemail_from, transcript, presigned_url)

    # Setup the email message
    message = MIMEMultipart()
    message["To"] = vm_email_target_address
    message["Subject"] = f"Voicemail from {voicemail_from}"

    message.attach(MIMEText(html_part, "html"))

    # Create the transcript attachment
    transcript_filename = "transcript.txt"
    transcript_attachment = MIMEBase("application", "octet-stream")
    transcript_attachment.set_payload(transcript.encode("utf-8"))
    encoders.encode_base64(transcript_attachment)
    transcript_attachment.add_header(
        "Content-Disposition", f"attachment; filename={transcript_filename}"
    )

    # Attach the transcript to the email
    message.attach(transcript_attachment)

    # Download the file using urllib
    try:
        with urllib.request.urlopen(presigned_url) as response:
            if response.status == 200:
                voicemail_filename = "voicemail.wav"
                voicemail_attachment = MIMEBase("application", "octet-stream")
                voicemail_attachment.set_payload(
                    response.read()
                )  # Read the file content

                encoders.encode_base64(voicemail_attachment)
                voicemail_attachment.add_header(
                    "Content-Disposition", f"attachment; filename={voicemail_filename}"
                )
                message.attach(voicemail_attachment)

            else:
                logger.error(
                    f"Failed to download voicemail file. Status code: {response.status} , contact_id: {contact_id}"
                )
                return "fail"
    except Exception as e:
        logger.error(
            f"Failed to download or attach voicemail file. contact_id: {contact_id}"
        )
        logger.error(e)
        return "fail"

    try:
        response = table.get_item(Key={'path': f"/vm-email-config/{lob_name}"})
        if 'Item' in response:
            smtp_server = response['Item']['smtp_server']
            smtp_port = int(response['Item']['smtp_port'])
            smtp_user = response['Item']['smtp_user']
            smtp_password = response['Item']['smtp_password']
        else:
            raise Exception("Item not found in DynamoDB")
    except Exception as e:
        print(f"Error fetching email config from DynamoDB: {e}")
        return None
    
    # Send the email using SMTP
    try:
        # Connect to SMTP server
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()  # Secure the connection
        if smtp_user and smtp_password:
            server.login(smtp_user, smtp_password)

        # Send the email
        server.sendmail(smtp_user, vm_email_target_address, message.as_string())
        server.quit()
        print("Email sent successfully!")
        logger.debug("********** Email request sent **********")
        return "success"

    except Exception as e:
        logger.error(f"Failed to send email , contact_id : {contact_id}")
        logger.error(e)
        return "fail"
