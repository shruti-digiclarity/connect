exports.handler = async (event, context) => {
    // Your function logic goes here
    const responseBody = {
        message: "Hello from Lambda!",
        input: event // The event object contains data passed to the function
    };

    const response = {
        statusCode: 200,
        body: JSON.stringify(responseBody),
        headers: {
            "Content-Type": "application/json"
        }
    };

    return response;
};
