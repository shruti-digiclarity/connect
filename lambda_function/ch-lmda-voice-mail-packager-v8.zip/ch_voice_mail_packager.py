import json
import os
import logging
import boto3
from botocore.config import Config
from datetime import datetime
from zoneinfo import ZoneInfo

import ch_voice_mail_ses_email
import ch_voice_mail_task

logger = logging.getLogger()

# Get table name from environment variable
TABLE_NAME = os.environ.get('CONFIG_TABLE_NAME')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):

    print(f"event : {event}")

    # Establish required clients and resources
    try:
        connect_client = boto3.client("connect")
        lambda_client = boto3.client("lambda")
        s3_client = boto3.client("s3")
        s3_resource = boto3.resource("s3")

    except Exception as e:
        logger.error("VM INITIALIZATION: Failed to initialize clients")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to initialize",
        }

    # Establish writer data
    writer_payload = {}

    # Establish data for transcript and recording, and clear out write tests.
    try:
        original_transcript_key = event["Records"][0]["s3"]["object"]["key"]
        print("original_transcript_key:", original_transcript_key)
        if original_transcript_key == ".write_access_check_file.temp":
            return "********** WRITE TEST - IGNORE **********"
        transcript_key = original_transcript_key[3:]
        transcript_job = transcript_key.replace(".json", "")
        contact_id = transcript_job.split("_", 1)[0]
        recording_key = contact_id + ".wav"
        transcript_bucket = os.environ["s3_transcripts_bucket"]
        recording_bucket = os.environ["s3_recordings_bucket"]
        print(f"contact_id : {contact_id}")

    except Exception as e:
        logger.error("Record Result: Failed to extract keys")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to extract keys",
        }

    # Extract the tags from the recording object
    try:
        object_data = s3_client.get_object_tagging(
            Bucket=recording_bucket, Key=recording_key
        )

        object_tags = object_data["TagSet"]
        loaded_tags = {}

        for i in object_tags:
            loaded_tags.update({i["Key"]: i["Value"]})

    except Exception as e:
        logger.error(
            f"Record Result: Failed to extract tags , contact_id : {contact_id}"
        )
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to extract tags",
        }

    # Grab the transcript from S3
    try:
        transcript_object = s3_resource.Object(
            transcript_bucket, original_transcript_key
        )
        file_content = transcript_object.get()["Body"].read().decode("utf-8")
        json_content = json.loads(file_content)
        transcript_contents = json_content["results"]["transcripts"][0]["transcript"]

    except Exception as e:
        logger.error(f"Failed to retrieve transcript , contact_id : {contact_id}")
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to retrieve transcript",
        }

    # Set instance attributes
    try:
        instance_id = loaded_tags["instance_id"]
        vm_from = loaded_tags["vm_from"]
        writer_payload.update({"instance_id": instance_id, "contact_id": contact_id})

    except Exception as e:
        logger.error(
            f"Record Result: Failed to set instance attributess , contact_id : {contact_id}"
        )
        logger.error(e)

        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to set instance attributes",
        }

    # Get the current date and time in UTC using timezone-aware objects
    try:
        current_datetime = datetime.now()
        ny_time = datetime.now(ZoneInfo("America/New_York"))
        formatted_datetime = ny_time.strftime("%A, %b %d at %I:%M %p (New York Time)")
        # formatted_datetime = current_datetime.strftime(
        #     "%A, %b %d at %I:%M %p (UTC Time)"
        # )

    except Exception as e:
        logger.error(
            f"Record Result: Failed to get timestamp , contact_id : {contact_id}"
        )
        logger.error(e)

        formatted_datetime = "UNKNOWN"

    # Get the existing contact attributes from the call and append the standard vars for voicemail to the attributes
    try:
        contact_attributes = connect_client.get_contact_attributes(
            InstanceId=instance_id, InitialContactId=contact_id
        )
        json_attributes = contact_attributes["Attributes"]
        json_attributes.update(
            {
                "transcript_contents": transcript_contents,
                "callback_number": vm_from,
                "vm_dateTime": formatted_datetime,
            }
        )
        writer_payload.update({"json_attributes": json_attributes})
        contact_attributes = json.dumps(contact_attributes["Attributes"])

    except Exception as e:
        logger.error(
            f"Record Result: Failed to extract attributes , contact_id : {contact_id}"
        )
        logger.error(e)

        contact_attributes = "UNKNOWN"

    try:
        lob_name = writer_payload["json_attributes"].get("lobName")
        response = table.get_item(Key={'path': f"/voicemail-config/{lob_name}"})
        is_email_agent_specific = writer_payload["json_attributes"].get("agentSpecific")
        print("response : ", response)
        if 'Item' in response:
            vm_task_queue_id = response['Item']['vm_task_queue_id']
            vm_from_email = response['Item']['vm_from_email']
            if is_email_agent_specific == "true":
                agentEmail = writer_payload["json_attributes"].get("agentEmail")
                vm_to_email = agentEmail
                vm_supervisor_email = response['Item']['vm_supervisor_email']
                vm_email_body = response['Item']['vm_agent_email_body']
            else:
                vm_to_email = response['Item']['vm_to_email']
                vm_email_body = response['Item']['vm_email_body']
        else:
            raise Exception("Item not found in DynamoDB")
    except Exception as e:
        print(f"Error fetching email config from DynamoDB: {e}")
        return None


    vm_mode = "task&email"

    # Invoke presigner Lambda to generate presigned URL for recording
    if vm_mode == "task&email":

        try:
            input_params = {
                "recording_bucket": recording_bucket,
                "recording_key": recording_key,
                "vm_mode": vm_mode,
                "contact_id": contact_id,
            }

            lambda_response = lambda_client.invoke(
                FunctionName=os.environ["presigner_function_arn"],
                InvocationType="RequestResponse",
                Payload=json.dumps(input_params),
            )
            response_from_presigner = json.load(lambda_response["Payload"])
            raw_url = response_from_presigner["presigned_url"]
            json_attributes.update({"presigned_url": raw_url})
            writer_payload.update({"presigned_url": raw_url})

        except Exception as e:
            logger.error(
                f"Record Result: Failed to generate presigned URL , contact_id : {contact_id}"
            )
            logger.error(e)

            return {
                "status": "complete",
                "result": "ERROR",
                "reason": "Failed to generate presigned URL",
            }

    if vm_mode == "task&email":

        try:
            if is_email_agent_specific == "true":
                send_email = ch_voice_mail_ses_email.vm_to_ses_email(
                   writer_payload, contact_id, vm_from_email, vm_to_email, vm_email_body, is_email_agent_specific, vm_supervisor_email
                )
            else:
                send_email = ch_voice_mail_ses_email.vm_to_ses_email(
                   writer_payload, contact_id, vm_from_email, vm_to_email, vm_email_body, is_email_agent_specific
                )
            create_task = ch_voice_mail_task.vm_to_connect_task(writer_payload, contact_id, vm_task_queue_id)

        except Exception as e:
            logger.error(
                f"Failed to activate email function , contact_id : {contact_id}"
            )
            logger.error(e)

            return {
                "status": "complete",
                "result": "ERROR",
                "reason": "Failed to activate email function",
            }

    else:
        logger.error(f"Invalid mode selection , contact_id : {contact_id}")
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Invalid mode selection",
        }

    if send_email == "success":
        print(f"VM email send successfully, contact_id : {contact_id}")
    else:
        logger.error(f"VM email failed to send, contact_id : {contact_id}")
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Record VM failed to send",
        }
    
    if create_task == "success":
        print(f"VM task successfully created , contact_id : {contact_id}")

    else:
        logger.error(f"VM failed to create task, contact_id : {contact_id}")
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Record VM failed to create task",
        }

    # Clear the vm_kvs_status for this contact
    try:
        update_flag = connect_client.update_contact_attributes(
            InitialContactId=contact_id,
            InstanceId=instance_id,
            Attributes={"vm_kvs_status": "0"},
        )

    except Exception as e:
        logger.error(f"Failed to change vm_kvs_status , contact_id : {contact_id}")
        logger.error(e)

    return {"status": "complete", "result": "Record processed"}
