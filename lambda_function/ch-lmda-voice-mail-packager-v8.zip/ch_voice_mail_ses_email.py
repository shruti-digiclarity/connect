import logging
import boto3
from botocore.config import Config
import os

logger = logging.getLogger()
    
# Function to replace dynamic placeholders with actual values
def replace_dynamic_values(html_content, voicemail_from, presigned_url, vm_date_time, agent_name=None, queue_alias=None):
    """Replaces dynamic placeholders in the HTML with actual values"""
    html_content = html_content.replace("{{voicemail_from}}", voicemail_from)
    # html_content = html_content.replace("{{transcript}}", transcript)
    html_content = html_content.replace("{{presigned_url}}", presigned_url)
    html_content = html_content.replace("{{vm_date_time}}", vm_date_time)

    # Only replace agent_name if it exists in template & provided
    if agent_name and "{{agent_name}}" in html_content:
        html_content = html_content.replace("{{agent_name}}", agent_name)
    if queue_alias and "{{queue_alias}}" in html_content:
        html_content = html_content.replace("{{queue_alias}}", queue_alias)

    return html_content

def vm_to_ses_email(
    writer_payload, contact_id, vm_from_email, vm_to_email, vm_email_body, is_email_agent_specific, vm_supervisor_email=None
):
    # print(f"writer_payload : {writer_payload} , contact_id : {contact_id}")

    # Establish clients (In this case, SMTP)
    try:
        ses_client = boto3.client('sesv2')
        print(f"SES Client initialized , contact_id : {contact_id}")
    except Exception as e:
        logger.error(
            f"VM Initialization Error: Could not initialize SMTP , contact_id : {contact_id}"
        )
        logger.error(e)
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to Initialize clients",
        }

    callback_number = writer_payload["json_attributes"].get("callback_number")
    cleaned_callback_number = callback_number.strip()
    phone_number = f"+{cleaned_callback_number}"

    if "@" not in vm_to_email:
        print("vm_to_email is not a valid email")
        return "fail"

    voicemail_from = phone_number
    presigned_url = writer_payload['json_attributes']['presigned_url']
    vm_date_time = writer_payload['json_attributes']['vm_dateTime']
    is_email_queue_specific = writer_payload["json_attributes"].get("queueSpecific")
    queue_alias = writer_payload["json_attributes"].get("vmQueueAlias")

     # Build ToAddresses and HTML body
    if is_email_agent_specific == "true":
        to_email_list = [vm_to_email, vm_supervisor_email]
        agent_name = writer_payload["json_attributes"].get("agentName", writer_payload["json_attributes"].get("agentEmail", "Agent"))
        html_part = replace_dynamic_values(vm_email_body, voicemail_from, presigned_url, vm_date_time, agent_name)
    elif is_email_queue_specific == "true":
        to_email_list = [vm_to_email]
        html_part = replace_dynamic_values(vm_email_body, voicemail_from, presigned_url, vm_date_time, agent_name=None, queue_alias=queue_alias)
    else:
        to_email_list = [vm_to_email]
        html_part = replace_dynamic_values(vm_email_body, voicemail_from, presigned_url, vm_date_time)

    print(f"to_email_list: {to_email_list}")
    
    # Send the email using SES
    try:
        if "uat" in os.environ.get('CONFIG_TABLE_NAME'):
            email_subject = f"UAT Voicemail from {voicemail_from}"
        else:
            email_subject = f"Voicemail from {voicemail_from}"

        send_email = ses_client.send_email(
            FromEmailAddress=vm_from_email,
            Destination={
                'ToAddresses': to_email_list,
            },
            Content={
                'Simple': {
                    'Subject': {
                        'Data': email_subject,
                        'Charset': 'UTF-8'
                    },
                    'Body': {
                        'Html': {
                            'Data': html_part,
                            'Charset': 'UTF-8'
                        }
                    }
                }
            }
        )
        print('********** Email request sent **********')
        print(send_email)

        return 'success'

    except Exception as e:
        logger.error(f"Failed to send email , contact_id : {contact_id}")
        logger.error(e)
        return "fail"
