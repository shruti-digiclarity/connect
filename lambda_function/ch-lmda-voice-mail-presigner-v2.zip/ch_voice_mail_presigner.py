import json
import boto3
import logging
from botocore.client import Config
import os

logger = logging.getLogger()


def lambda_handler(event, context):

    print(f"event : {event}")
    contact_id = event["contact_id"]
    print(f"contact_id : {contact_id}")

    response = {}

    response.update({"result": "success"})

    # Retrieve credentials from AWS Secrets Manager
    try:
        use_keys = get_secret()
        print('********** Successfully retrieved keys **********')

    except Exception as e:
        logger.error('********** Key retrieval failed **********')
        logger.error(e)
        
        response.update({'status':'complete','result':'ERROR','reason':'key retrieval failed'})

        return response

    try:
        use_region = os.environ["AWS_REGION"]

        # Set the sig version and config options
        my_config = Config(
            region_name=use_region,
            signature_version="s3v4",
            retries={"max_attempts": 10, "mode": "standard"},
        )
        # s3_client = boto3.client("s3", config=my_config)
        s3_client = boto3.client(
            's3',
            endpoint_url = 'https://s3.' + use_region + '.amazonaws.com',
            aws_access_key_id = use_keys['access_key_id'],
            aws_secret_access_key = use_keys['secret_access_key'],
            config=my_config
        )

    except Exception as e:
        logger.error(f"S3 client failed to initialize , contact_id : {contact_id}")
        logger.error(e)
        response.update(
            {"status": "complete", "result": "ERROR", "reason": "s3 client init failed"}
        )

        return response

    # Generate the presigned URL and return
    try:

        # vm_mode = event["vm_mode"]
        expires_in = 7 * 86400

        presigned_url = s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": event["recording_bucket"], "Key": event["recording_key"]},
            ExpiresIn=expires_in,
        )

        print(f"Presigned URL: {presigned_url}")
        response.update({"presigned_url": presigned_url})

        return response

    except Exception as e:
        logger.error(f"Presigned URL Failed to generate , contact_id : {contact_id}")
        logger.error(e)
        response.update(
            {
                "status": "complete",
                "result": "ERROR",
                "reason": "presigned url generation failed",
            }
        )

        return response

# Sub to retrieve the secrets from Secrets Manager
def get_secret():
    # Set response container
    secret_response = {}

    # Set secrets environment
    try:
        secret_name = os.environ['secrets_key_id']
        region_name = os.environ['AWS_REGION']
        print('********** Secrets environment vars set **********')

    except Exception as e:
        logger.error('********** Secrets environment vars failed to set **********')
        logger.error(e)
        secret_response.update({'status':'complete','result':'ERROR','reason':'environment vars failed'})

        return secret_response

    # Create a Secrets Manager session
    try:
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name
        )

        print('********* Secrets session initialized **********')

    except Exception as e:
        logger.error('********** Secrets session failed to initialize **********')
        logger.error(e)
        secret_response.update({'status':'complete','result':'ERROR','reason':'AWS Secrets Manager session failed'})

        return secret_response

    # Get the secrets
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        secret = get_secret_value_response['SecretString']
        secret_response.update(json.loads(secret))

        logger.debug('********** Successfully retrieved secrets **********')

        return secret_response

    except Exception as e:
        logger.error('********** Failed to get secrets **********')
        logger.error(e)
        secret_response.update({'status':'complete','result':'ERROR','reason':'failed to get secrets'})

        return secret_response