import logging
import boto3
from botocore.config import Config

logger = logging.getLogger()
    
# Function to replace dynamic placeholders with actual values
def replace_dynamic_values(html_content, voicemail_from):
    """Replaces dynamic placeholders in the HTML with actual values"""
    html_content = html_content.replace("{{voicemail_from}}", voicemail_from)
    # html_content = html_content.replace("{{transcript}}", transcript)
    # html_content = html_content.replace("{{presigned_url}}", presigned_url)
    return html_content

def vm_to_ses_email(
    writer_payload, contact_id, vm_from_email, vm_to_email, vm_email_body
):
    print(f"writer_payload : {writer_payload} , contact_id : {contact_id}")

    # Establish clients (In this case, SES)
    try:
        ses_client = boto3.client('sesv2')
        print(f"SES Client initialized , contact_id : {contact_id}")
    except Exception as e:
        logger.error(
            f"VM Initialization Error: Could not initialize SES , contact_id : {contact_id}"
        )
        logger.error(e)
        return {
            "status": "complete",
            "result": "ERROR",
            "reason": "Failed to Initialize clients",
        }

    callback_number = writer_payload["json_attributes"].get("callback_number")
    cleaned_callback_number = callback_number.strip()
    phone_number = f"+{cleaned_callback_number}"

    if "@" not in vm_to_email:
        print("vm_to_email is not a valid email")
        return "fail"

    voicemail_from = phone_number

    html_part = replace_dynamic_values(vm_email_body, voicemail_from)
    
    # Send the email using SES
    try:
        email_subject = f"Voicemail from {voicemail_from}"

        send_email = ses_client.send_email(
            FromEmailAddress=vm_from_email,
            Destination={
                'ToAddresses': [
                    vm_to_email,
                ],
            },
            Content={
                'Simple': {
                    'Subject': {
                        'Data': email_subject,
                        'Charset': 'UTF-8'
                    },
                    'Body': {
                        'Html': {
                            'Data': html_part,
                            'Charset': 'UTF-8'
                        }
                    }
                }
            }
        )
        print('********** Email request sent **********')
        print(send_email)

        return 'success'

    except Exception as e:
        logger.error(f"Failed to send email , contact_id : {contact_id}")
        logger.error(e)
        return "fail"
